# 🔥 Kinkntease Platform

Complete adult social networking platform with chat, messaging, profiles, and premium features.

![Status](https://img.shields.io/badge/status-production-brightgreen)
![Version](https://img.shields.io/badge/version-3.31-blue)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-777BB4)
![Database](https://img.shields.io/badge/MySQL-8.0%2B-4479A1)

---

## 🚀 Quick Start

### Installation

1. **Upload Files**
   ```bash
   # Upload to your hosting
   backend.php → /public_html/api/index.php
   frontend.html → /public_html/kinkntease-v4-CLEAR-LOGIN.html
   ```

2. **Database Setup**
   - Database already exists: `db9hmsktz1ntus`
   - Optional: Run `database/notifications-rebuild.sql` if notifications need reset

3. **Access**
   - Navigate to: `https://kinkntease.com`
   - Admin login: Use your admin account

---

## ✨ Features

### 🔐 Password Management (Complete)

**3 Password Reset Methods:**
- **Admin Reset** - Admins can reset any user's password from dashboard
- **User Self-Reset** - Users can change their own password in profile settings
- **Forgot Password** - Email-based password recovery on login page

### 💬 Messaging & Communication

- **Direct Messages** - Private 1-on-1 messaging with read receipts
- **Chat Rooms** - Public and private chat rooms
- **Voice Messages** - Record and send voice messages
- **Photo Sharing** - Send photos in DMs and chat rooms
- **Video Calls** - Integrated video calling
- **Emojis** - Full emoji picker

### 🔔 Notifications

**Completely Rebuilt System:**
- Auto-clears badges when viewed
- Marks notifications as read automatically
- Real-time updates
- Filter by type (all, messages, views, social)
- Sound alerts
- Email notifications

### 👤 Profile System

- **Photo Galleries** - Upload up to 12 photos per profile
- **Voice Recordings** - Up to 5 voice intros (2 min each)
- **Star Ratings** - Users can rate photos (1-5 stars)
- **Profile Visitors** - Track who viewed your profile
- **Watermarks** - Automatic watermarking on photos
- **Custom Avatars** - Profile pictures with cropping

### 👥 Social Features

- **Winks** - Send flirty winks to other users
- **Favorites** - Save favorite profiles
- **Gifts** - Virtual gift system
- **User Blocking** - Block unwanted users
- **Friend Lists** - Manage connections

### 💎 Premium Features

- **Membership Tiers** - Free, Premium, VIP
- **Promo Codes** - Discount and trial codes
- **Coins System** - Virtual currency
- **Premium Badges** - Visual status indicators

### ⚙️ Admin Dashboard

**Complete Admin Control:**
- User management (ban, unban, delete)
- Password resets for any user
- Grant/revoke premium status
- Platform statistics
- Chat room moderation
- Activity monitoring

---

## 📋 Technical Details

### Stack

- **Frontend**: Vanilla JavaScript (SPA)
- **Backend**: PHP 7.4+
- **Database**: MySQL 8.0+
- **Storage**: File-based uploads
- **Email**: PHP mail() function
- **Sessions**: PHP session management

### File Structure

```
/public_html/
├── index.html                    # Landing page
├── kinkntease-v4-CLEAR-LOGIN.html  # Main application (frontend.html)
├── api/
│   └── index.php                 # Backend API (backend.php)
├── uploads/
│   ├── avatars/                  # Profile pictures
│   ├── gallery/                  # Gallery photos
│   ├── messages/                 # Message attachments
│   └── voice/                    # Voice recordings
└── verify.html                   # Email verification page
```

### Database Tables

**Core Tables:**
- `users` - User accounts and authentication
- `profiles` - Extended profile information
- `messages` - Direct messages
- `notifications` - Notification system (with foreign keys)
- `rooms` - Chat rooms
- `room_messages` - Chat room messages

**Social Tables:**
- `winks` - Wink interactions
- `favorites` - Favorite profiles
- `gifts` - Virtual gifts
- `blocked_users` - User blocking
- `profile_visitors` - Profile view tracking

**Media Tables:**
- `gallery_photos` - User photo galleries
- `voice_recordings` - Voice messages
- `stories` - User stories/posts

---

## 🔧 Configuration

### Admin Setup

Make a user admin:
```sql
UPDATE users SET is_admin = 1 WHERE username = 'YourUsername';
```

### Email Configuration

Edit in `backend.php`:
```php
// Email settings (line ~400)
$headers .= "From: Kink N Tease <noreply@kinkntease.com>\r\n";
```

### Premium Pricing

Configure in admin dashboard or directly in database:
```sql
-- Update subscription prices
UPDATE users SET subscription_type = 'premium', premium_until = DATE_ADD(NOW(), INTERVAL 30 DAY) WHERE id = X;
```

---

## 🧪 Testing

### Password Reset Flow

**Admin Reset:**
1. Login as admin
2. Dashboard → Users tab
3. Click 🔑 button next to any user
4. Set new password → Copy to clipboard
5. Share with user

**User Self-Reset:**
1. Login as user
2. Profile → Edit Profile
3. Scroll to "🔐 Account Security"
4. Click "🔑 Change Your Password"
5. Enter current + new password

**Forgot Password:**
1. Go to login page
2. Click "🔑 Forgot Password?"
3. Enter email address
4. Check email for temp password
5. Login with temp password
6. Change in profile settings

---

## 📊 Version History

### v3.31 (Current) - December 6, 2025
- ✅ Complete password management (3 methods)
- ✅ Rebuilt notification system
- ✅ Fixed admin content section
- ✅ Enhanced message sending
- ✅ Profile ID fixes

### v3.19 - Previous Stable
- ✅ Notification system base
- ✅ Profile fixes
- ✅ Home button
- ✅ All core features

### Earlier Versions
- Facebook migration
- Email verification
- Premium membership
- Chat rooms
- Voice/video features

**Total Changes:** 31 major updates

---

## 🐛 Troubleshooting

### Notifications Not Clearing

**Solution:**
```sql
-- Run this SQL in phpMyAdmin
-- See: database/notifications-rebuild.sql
```

### Password Reset Email Not Received

**Check:**
1. Spam folder
2. Email exists in database
3. Server mail() function enabled
4. DNS/SPF records configured

### Admin Dashboard Not Accessible

**Verify:**
```sql
SELECT username, is_admin FROM users WHERE is_admin = 1;
```

### Syntax Errors

1. Clear browser cache (Ctrl + Shift + F5)
2. Hard refresh
3. Check console for specific error
4. Re-upload files

---

## 🔐 Security

### Password Storage
- Passwords hashed using `password_hash()` (bcrypt)
- Salted automatically
- Never stored in plain text

### Session Management
- PHP sessions with regeneration
- Secure session cookies
- Timeout after inactivity

### Input Validation
- All user input sanitized
- SQL injection prevention (prepared statements)
- XSS protection
- CSRF tokens (to be implemented)

### File Uploads
- Type validation
- Size limits
- Secure storage path
- Watermarking

---

## 📈 Performance

### Optimization
- Single-page application (SPA) architecture
- Lazy loading for images
- Efficient SQL queries with indexes
- Session-based authentication (fast)
- CDN-ready static assets

### Caching
- Browser caching for static assets
- Session caching for user data
- Query result caching (future)

---

## 🚀 Deployment

### Production Checklist

- [ ] Upload backend.php to `/api/index.php`
- [ ] Upload frontend.html to `/kinkntease-v4-CLEAR-LOGIN.html`
- [ ] Verify database connection
- [ ] Test email functionality
- [ ] Create admin account
- [ ] Configure email settings
- [ ] Test all 3 password reset methods
- [ ] Verify notifications work
- [ ] Check file upload permissions
- [ ] Enable HTTPS
- [ ] Set up backups

### Environment

**Hosting:** HostGator
**Database:** db9hmsktz1ntus
**Domain:** kinkntease.com
**PHP Version:** 7.4+
**MySQL Version:** 8.0+

---

## 📝 API Endpoints

### Authentication
- `POST /api/?endpoint=auth&action=login`
- `POST /api/?endpoint=auth&action=register`
- `POST /api/?endpoint=auth&action=logout`
- `POST /api/?endpoint=auth&action=forgot-password`
- `POST /api/?endpoint=auth&action=change-password`

### Users
- `GET /api/?endpoint=users&action=list`
- `GET /api/?endpoint=users&action=profile`
- `POST /api/?endpoint=users&action=update`

### Messages
- `GET /api/?endpoint=messages&action=conversations`
- `GET /api/?endpoint=messages&action=list`
- `POST /api/?endpoint=messages&action=send`

### Notifications
- `GET /api/?endpoint=notifications&action=list`
- `POST /api/?endpoint=notifications&action=mark-read`

### Admin
- `GET /api/?endpoint=admin&action=users`
- `POST /api/?endpoint=admin&action=reset-password`
- `POST /api/?endpoint=admin&action=ban-user`

---

## 🤝 Contributing

This is a private project, but improvements are welcome:

1. Fork the repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Open pull request

---

## 📄 License

Proprietary - All rights reserved

---

## 📞 Support

**Developer:** Peet (Abuntu Digital)
**Website:** abuntudigital.com
**GitHub:** https://github.com/Peetvan/kinkntease-platform

---

## 🎯 Roadmap

### Planned Features
- [ ] Content moderation backend
- [ ] Payment gateway integration
- [ ] User reporting system
- [ ] Enhanced analytics dashboard
- [ ] Mobile app API
- [ ] Push notifications
- [ ] Advanced search filters
- [ ] Story/feed feature
- [ ] Live streaming

### Under Consideration
- [ ] AI-powered matching
- [ ] Blockchain verification
- [ ] NFT profile badges
- [ ] Multi-language support
- [ ] Desktop application

---

## ⚡ Quick Links

- **Live Site:** https://kinkntease.com
- **Admin Dashboard:** https://kinkntease.com (login as admin)
- **GitHub:** https://github.com/Peetvan/kinkntease-platform
- **Documentation:** See BACKUP-INFO.txt

---

## 📊 Stats

- **Frontend:** 6,169 lines
- **Backend:** 2,903 lines  
- **Total Code:** 9,072 lines
- **Database Tables:** 20+
- **Features:** 50+
- **Development Time:** Extensive
- **Status:** Production Ready ✅

---

**Built with ❤️ for the adult social networking community**

*Last Updated: December 6, 2025*
