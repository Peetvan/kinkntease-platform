# 🚀 Deployment Instructions

Quick guide to deploy Kinkntease to production server.

---

## 📋 Prerequisites

- HostGator hosting account
- FTP/File Manager access
- phpMyAdmin access
- Database: `db9hmsktz1ntus`

---

## 🔧 Deployment Steps

### 1. Backup Current Version (IMPORTANT!)

```bash
# Via File Manager or FTP
# Download current versions:
- /public_html/api/index.php
- /public_html/kinkntease-v4-CLEAR-LOGIN.html
```

### 2. Upload New Files

**Backend:**
```
Source: backend.php
Destination: /public_html/api/index.php
Method: FTP or File Manager
Permission: 644
```

**Frontend:**
```
Source: frontend.html
Destination: /public_html/kinkntease-v4-CLEAR-LOGIN.html
Method: FTP or File Manager
Permission: 644
```

### 3. Database (Optional)

Only if notifications need reset:

```sql
-- Login to phpMyAdmin
-- Select database: db9hmsktz1ntus
-- Run: database/notifications-rebuild.sql
```

### 4. Verify Upload

Check file sizes match:
- backend.php: ~145KB
- frontend.html: ~294KB

### 5. Clear Cache

```
Browser: Ctrl + Shift + F5
Or: Settings → Clear browsing data
```

### 6. Test Features

- [ ] Login/logout
- [ ] Forgot password email
- [ ] User password change
- [ ] Admin password reset
- [ ] Notifications clear
- [ ] Messages send
- [ ] Admin dashboard

---

## ⚙️ Configuration

### Email Settings

Edit `backend.php` line ~400:

```php
$headers .= "From: Kink N Tease <noreply@kinkntease.com>\r\n";
```

### Admin Account

Set admin privileges:

```sql
UPDATE users SET is_admin = 1 WHERE username = 'YourUsername';
```

---

## 🐛 Troubleshooting

### File Upload Fails

**Solution:**
1. Check file permissions (should be 644)
2. Verify file size limits
3. Try different upload method (FTP vs File Manager)

### Database Connection Error

**Check:**
```php
// In backend.php
$db = new PDO("mysql:host=localhost;dbname=db9hmsktz1ntus", "username", "password");
```

### 500 Internal Server Error

**Debug:**
1. Check PHP error logs
2. Verify PHP version (7.4+)
3. Check file permissions
4. Ensure all files uploaded completely

### Forgot Password Not Sending

**Verify:**
1. Server mail() function enabled
2. SPF/DKIM records configured
3. From email not blacklisted
4. Check spam folder

---

## 🔄 Rollback Procedure

If deployment fails:

1. **Stop** - Don't make more changes
2. **Restore** - Upload previous backup files
3. **Test** - Verify old version works
4. **Debug** - Check error logs
5. **Fix** - Resolve issues before retrying

---

## ✅ Post-Deployment Checklist

After deployment, verify:

- [ ] Site loads without errors
- [ ] Users can login
- [ ] Messages work
- [ ] Notifications display
- [ ] Admin dashboard accessible
- [ ] Password resets function
- [ ] Emails sending
- [ ] File uploads work
- [ ] Chat rooms function
- [ ] Premium features work

---

## 📊 Monitoring

### Check These Regularly

**Error Logs:**
```
/public_html/error_log
Check for PHP warnings/errors
```

**Database:**
```sql
-- Check active users
SELECT COUNT(*) FROM users WHERE is_online = 1;

-- Check unread notifications
SELECT COUNT(*) FROM notifications WHERE is_read = 0;

-- Check message count
SELECT COUNT(*) FROM messages WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 DAY);
```

**Server Resources:**
- CPU usage
- Memory usage
- Disk space
- Bandwidth

---

## 🔐 Security Reminders

- [ ] Keep database credentials secure
- [ ] Use HTTPS (SSL certificate)
- [ ] Regular backups
- [ ] Monitor error logs
- [ ] Update PHP version
- [ ] Review admin access regularly

---

## 📞 Support

**Issues?**
- Check error logs first
- Review CHANGELOG.md
- See README.md troubleshooting section
- Check GitHub issues

---

## 📝 Deployment Log Template

```
Date: _______________
Time: _______________
Version: v3.31
Deployed by: _______________

Files Uploaded:
- [ ] backend.php
- [ ] frontend.html

Database Changes:
- [ ] None / notifications-rebuild.sql

Tests Passed:
- [ ] Login
- [ ] Password reset
- [ ] Notifications
- [ ] Messages
- [ ] Admin dashboard

Issues Found:
_______________________________________________
_______________________________________________

Resolution:
_______________________________________________
_______________________________________________

Deployment Status: ✅ Success / ❌ Failed / ⏸️ Rolled Back
```

---

**Ready to deploy!** 🚀

*Follow these steps carefully for a smooth deployment.*
