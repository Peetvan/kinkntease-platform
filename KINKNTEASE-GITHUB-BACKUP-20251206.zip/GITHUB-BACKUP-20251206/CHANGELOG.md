# Changelog

All notable changes to the Kinkntease platform.

---

## [v3.31] - 2025-12-06 - CURRENT

### ✨ Added
- **Forgot Password** - Email-based password recovery on login page
- Users can request temporary password via email
- Beautiful HTML email template for password resets
- Auto-redirect to login after password reset

### 🔧 Changed
- Password reset button in profile now more visible (orange, larger)
- Added "🔐 Account Security" section header in Edit Profile
- Enhanced password change prompts with better instructions

### 📦 Files Changed
- `frontend.html` (v3.31)
- `backend.php` (v3.17)

---

## [v3.30] - 2025-12-06

### 🎨 Improved
- Made "Change Your Password" button highly visible in profile
- Changed button color to orange (#f39c12)
- Increased button size and padding
- Added section header for better UX

### 📦 Files Changed
- `frontend.html` (v3.30)

---

## [v3.29] - 2025-12-06

### 🐛 Fixed
- Admin content section no longer shows infinite spinner
- Shows professional "Coming Soon" placeholder instead
- Removed broken API calls for content management

### 📦 Files Changed
- `frontend.html` (v3.29)

---

## [v3.28] - 2025-12-06

### 🐛 Fixed
- Attempted fix for admin content section
- Syntax errors resolved

---

## [v3.27] - 2025-12-06

### ✨ Added
- **Complete Notification System Rebuild**
- Notifications now clear badges immediately
- Auto-mark as read when modal opens
- Better error handling
- Filter notifications by type

### 🔧 Changed
- Badge clears to 0 instantly when clicked
- Notifications marked as read automatically after 500ms
- Server count refresh after marking read
- Enhanced visual feedback

### 🐛 Fixed
- Badges no longer stay stuck
- Notifications actually clear properly
- No more notification count mismatches

### 📦 Files Changed
- `frontend.html` (v3.27)

---

## [v3.26] - 2025-12-06

### 🐛 Fixed
- **Message sending issues**
- Users can now respond to messages
- Better error messages when send fails
- Input validation before sending
- Restores message text if send fails
- Disables input while sending (prevents double-send)

### 📦 Files Changed
- `frontend.html` (v3.26)

---

## [v3.25] - 2025-12-06

### ✨ Added
- **User Self-Password Change**
- Users can change their own password from Edit Profile
- Validates current password before allowing change
- Confirms new password matches
- Shows success/error messages

### 🔧 Changed
- Added "Change Password" button in Edit Profile modal
- Password change requires current password verification

### 📦 Files Changed
- `frontend.html` (v3.25)
- `backend.php` (v3.16)

---

## [v3.24] - 2025-12-06

### ✨ Added
- **Admin Password Reset**
- Admins can reset any user's password
- Copy password to clipboard feature
- Shows username in success message
- Orange 🔑 button in admin users table

### 📦 Files Changed
- `frontend.html` (v3.24)
- `backend.php` (v3.15)

---

## [v3.23] - 2025-12-06

### 🏷️ Tagged
- Known working version before password reset features
- All core features functional
- Notifications, profiles, messaging working

---

## [v3.19] - 2025-12-05

### ✨ Added
- Complete notification system with foreign keys
- Home button (inline with logo)
- Badge clearing on notification view
- Email notification system

### 🐛 Fixed
- Profile ID bug (p.id vs p.user_id)
- Notification clicks leading to wrong profiles
- Notification count mismatches
- Badge not clearing after viewing

### 📦 Database Changes
- `new-notification-system.sql` - Rebuilt notifications table
- Added foreign keys with ON DELETE CASCADE
- INNER JOIN in notification queries

---

## [v3.0-v3.18] - 2025-12-05

### ✨ Added
- Phase 1 chat enhancements
- Clickable usernames (green, bold, hover)
- Timestamps in chat
- Unread message counter
- Visitors page
- Profile rendering fixes
- Multiple debug versions

### 🐛 Fixed
- Profile click handlers
- Chat room navigation
- Message routing
- User identification

---

## [v2.0] - Earlier

### ✨ Added
- Facebook migration system
- Email verification
- Watermark system
- Avatar system with cropping
- Premium membership
- Promo codes
- Admin privileges
- Star rating system
- Photo locking
- User blocking
- Message read receipts
- Sound notifications

---

## [v1.0] - Initial Release

### ✨ Initial Features
- User registration and login
- Profile system
- Direct messaging
- Chat rooms
- Photo galleries
- Voice recordings
- Basic admin dashboard
- Social features (winks, favorites, gifts)
- Premium membership tiers

---

## 📊 Change Summary

**Total Versions:** 31+
**Major Features Added:** 50+
**Bug Fixes:** 20+
**Lines of Code:** 9,072
**Development Duration:** Extensive

---

## 🔜 Upcoming

### Planned for Next Release
- Content moderation backend
- Payment gateway integration
- User reporting system
- Enhanced analytics
- Mobile app API

---

*For detailed feature information, see README.md*
