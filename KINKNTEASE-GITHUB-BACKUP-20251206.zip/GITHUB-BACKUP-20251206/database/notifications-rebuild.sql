-- =====================================================
-- COMPLETE NEW NOTIFICATION SYSTEM
-- Drop old, create new with better structure
-- =====================================================

-- Step 1: Backup old table (just in case)
CREATE TABLE IF NOT EXISTS notifications_backup_old AS SELECT * FROM notifications;

-- Step 2: Drop old notification table
DROP TABLE IF EXISTS notifications;

-- Step 3: Create new improved notification table
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    from_user_id INT NOT NULL,
    type ENUM('message', 'wink', 'view', 'favorite', 'gift', 'vm_like') NOT NULL,
    message TEXT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    read_at TIMESTAMP NULL,
    
    -- Indexes for performance
    INDEX idx_user_unread (user_id, is_read),
    INDEX idx_user_created (user_id, created_at DESC),
    INDEX idx_from_user (from_user_id),
    
    -- Foreign keys to ensure data integrity
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Step 4: Verify the new table
DESCRIBE notifications;

-- Step 5: Check counts
SELECT 'New notification table created successfully' as status;
SELECT COUNT(*) as old_notifications_backed_up FROM notifications_backup_old;
SELECT COUNT(*) as new_notifications FROM notifications;

-- =====================================================
-- DONE! Fresh notification system ready to use
-- =====================================================

-- Note: You can drop the backup table later with:
-- DROP TABLE IF EXISTS notifications_backup_old;
